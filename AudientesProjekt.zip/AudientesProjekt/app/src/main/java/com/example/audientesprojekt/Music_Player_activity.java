package com.example.audientesprojekt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Music_Player_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_player);
    }
}