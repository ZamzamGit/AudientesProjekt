package com.example.audientesprojekt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Option_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option_);
    }
}