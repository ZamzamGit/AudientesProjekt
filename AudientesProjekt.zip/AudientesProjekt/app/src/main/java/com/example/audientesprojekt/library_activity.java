package com.example.audientesprojekt;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class library_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_library);
    }
}